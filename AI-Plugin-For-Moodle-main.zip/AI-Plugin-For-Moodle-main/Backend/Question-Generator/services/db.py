# services/db.py
import os
import json
import uuid
from datetime import datetime
from typing import Dict, List, Optional, Any, Set

from dotenv import load_dotenv

# Firestore is optional – we'll try to initialize and fall back to local JSON.
try:
    import firebase_admin
    from firebase_admin import credentials, firestore
except Exception:
    firebase_admin = None
    credentials = None
    firestore = None

load_dotenv()

FIREBASE_SERVICE_ACCOUNT_PATH = os.getenv("FIREBASE_SERVICE_ACCOUNT_PATH")

# ---------- Local JSON fallback paths ----------
BASE_DIR = os.path.dirname(os.path.dirname(__file__))  # .../Question-Generator
DATA_DIR = os.path.join(BASE_DIR, "data", "quizzes")
os.makedirs(DATA_DIR, exist_ok=True)

def _local_path(qid: str) -> str:
    return os.path.join(DATA_DIR, f"{qid}.json")

def _now_iso() -> str:
    return datetime.utcnow().isoformat() + "Z"


# ---------- Firestore init ----------
_db = None
if firebase_admin and credentials and firestore:
    try:
        if not firebase_admin._apps:
            cred = credentials.Certificate(FIREBASE_SERVICE_ACCOUNT_PATH)
            firebase_admin.initialize_app(cred)
        _db = firestore.client()
        print("✅ Firestore initialized in services/db.py")
    except Exception as e:
        print(f"⚠️ Firestore init failed (services/db.py): {e}")
        _db = None
else:
    print("ℹ️ Firestore libraries not available; using local JSON storage.")


# ----------------------------------------------------
#   SAVE QUIZ/ASSIGNMENT
# ----------------------------------------------------

def save_quiz(quiz: Dict[str, Any]) -> str:
    """
    Save quiz or assignment based on metadata.kind.
    - metadata.kind == 'assignment' → goes to 'assignments'
    - otherwise → goes to 'AIquizzes'
    """
    qid = quiz.get("id") or str(uuid.uuid4())
    quiz["id"] = qid
    quiz["title"] = quiz.get("title") or quiz.get("metadata", {}).get("source_file") or "AI Generated Content"
    quiz["created_at"] = quiz.get("created_at") or datetime.utcnow()

    # Ensure `settings` dictionary exists and is consistent
    settings = quiz.get('settings', {}) or {}

    if not settings:
        settings = {
            'time_limit': quiz.get('time_limit', 30),
            'due_date': quiz.get('due_date', None),
            'note': quiz.get('note', quiz.get('additional note', '')),
            'allow_retakes': quiz.get('allow_retakes', False),
            'shuffle_questions': quiz.get('shuffle_questions', True)
        }

    quiz['settings'] = settings
    quiz['time_limit'] = settings.get('time_limit')
    quiz['due_date'] = settings.get('due_date')
    quiz['note'] = settings.get('note')

    if 'is_allowed' not in quiz:
        quiz['is_allowed'] = False

    # Normalize question IDs
    for q in quiz.get("questions", []):
        if not q.get("id"):
            q["id"] = str(uuid.uuid4())
        if not q.get("prompt") and q.get("question_text"):
            q["prompt"] = q["question_text"]

    # Detect collection
    metadata = quiz.get("metadata", {})
    detected_kind = metadata.get("kind", "quiz")

    if detected_kind == "assignment":
        collection_name = "assignments"
    else:
        collection_name = "AIquizzes"

    print(f"💾 Saving to collection '{collection_name}' with ID: {qid}")

    if _db:
        try:
            _db.collection(collection_name).document(qid).set(quiz)
            print(f"✅ Saved to Firestore: {collection_name}/{qid}")
            return qid
        except Exception as e:
            print(f"⚠️ Firestore save failed; fallback to local. Error: {e}")

    # Local JSON fallback
    if isinstance(quiz.get("created_at"), datetime):
        quiz["created_at"] = quiz["created_at"].isoformat()

    with open(_local_path(qid), "w", encoding="utf-8") as f:
        json.dump(quiz, f, ensure_ascii=False, indent=2)

    print(f"✅ Saved locally: {_local_path(qid)}")
    return qid


# ----------------------------------------------------
#   GET QUIZ/ASSIGNMENT
# ----------------------------------------------------
def get_quiz_by_id(quiz_id: str) -> Optional[Dict[str, Any]]:
    print(f"🔍 Looking for quiz/assignment with ID: {quiz_id}")

    if _db:
        try:
            for col in ["AIquizzes", "assignments"]:
                d = _db.collection(col).document(quiz_id).get()
                if d.exists:
                    q = d.to_dict() or {}
                    q["id"] = quiz_id
                    print(f"✅ Found in {col}: {q.get('title', 'No title')}")
                    return q
        except Exception as e:
            print(f"⚠️ Firestore get failed; falling back to local. Error: {e}")

    path = _local_path(quiz_id)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            print(f"✅ Found locally: {data.get('title', 'No title')}")
            return data

    print(f"❌ Not found: {quiz_id}")
    return None


# ----------------------------------------------------
#   ONE-ATTEMPT ENFORCEMENT
# ----------------------------------------------------

def has_student_submitted(quiz_id: str, student_email: str) -> bool:
    """
    Check if a specific student has already submitted a specific quiz/assignment.
    Returns True if already submitted (block re-attempt), False if first attempt.
    Checks both Firestore collections.
    """
    if not student_email or not quiz_id:
        return False

    student_email = student_email.strip().lower()

    if _db:
        try:
            for col in ["AIquizzes", "assignments"]:
                subs = (
                    _db.collection(col)
                    .document(quiz_id)
                    .collection("submissions")
                    .where("student_email", "==", student_email)
                    .limit(1)
                    .get()
                )
                if subs:
                    print(f"🚫 {student_email} already submitted {quiz_id} in {col}")
                    return True
        except Exception as e:
            print(f"⚠️ has_student_submitted Firestore check failed: {e}")
            # On error, allow the attempt (fail open) to avoid blocking students
            return False

    # Local JSON fallback: check submissions subfolder
    submissions_dir = os.path.join(DATA_DIR, "submissions", quiz_id)
    if os.path.exists(submissions_dir):
        for fname in os.listdir(submissions_dir):
            if not fname.endswith(".json"):
                continue
            try:
                with open(os.path.join(submissions_dir, fname)) as f:
                    sub = json.load(f)
                if (sub.get("student_email") or "").strip().lower() == student_email:
                    return True
            except Exception:
                continue

    return False


def get_submitted_quiz_ids(student_email: str) -> Set[str]:
    """
    Return the set of quiz/assignment IDs that a student has already submitted.
    Used to filter out already-attempted items on the student dashboard.
    """
    if not student_email:
        return set()

    student_email = student_email.strip().lower()
    submitted_ids: Set[str] = set()

    if _db:
        try:
            for col in ["AIquizzes", "assignments"]:
                for qdoc in _db.collection(col).stream():
                    qid = qdoc.id
                    subs = (
                        _db.collection(col)
                        .document(qid)
                        .collection("submissions")
                        .where("student_email", "==", student_email)
                        .limit(1)
                        .get()
                    )
                    if subs:
                        submitted_ids.add(qid)
        except Exception as e:
            print(f"⚠️ get_submitted_quiz_ids failed: {e}")

    return submitted_ids


# ----------------------------------------------------
#   LIST QUIZZES + ASSIGNMENTS
# ----------------------------------------------------
def list_quizzes(kind: Optional[str] = None) -> List[Dict[str, Any]]:
    print(f"📋 Listing. Filter by kind: {kind}")
    items: List[Dict[str, Any]] = []

    if _db:
        try:
            collections_to_search = []
            if kind == "assignment":
                collections_to_search = ["assignments"]
            elif kind == "quiz":
                collections_to_search = ["AIquizzes"]
            else:
                collections_to_search = ["AIquizzes", "assignments"]

            for col in collections_to_search:
                docs = _db.collection(col).order_by("created_at", direction=firestore.Query.DESCENDING).stream()

                for d in docs:
                    q = d.to_dict() or {}
                    qid = q.get("id") or d.id
                    title = q.get("title") or "Untitled"
                    meta = q.get("metadata") or {}
                    settings = q.get("settings", {}) or {}

                    settings.setdefault('time_limit', q.get('time_limit'))
                    settings.setdefault('due_date', q.get('due_date'))
                    settings.setdefault('note', q.get('note'))

                    item_kind = "assignment" if col == "assignments" else meta.get("kind", "quiz")

                    questions = q.get("questions", [])
                    counts = {}
                    for question in questions:
                        qtype = question.get("type", "unknown")
                        counts[qtype] = counts.get(qtype, 0) + 1

                    items.append({
                        "id": qid,
                        "title": title,
                        "created_at": q.get("created_at"),
                        "questions_count": len(questions),
                        "counts": counts,
                        "questions": questions,
                        "metadata": meta,
                        "settings": settings,
                        "time_limit": settings.get('time_limit'),
                        "due_date": settings.get('due_date'),
                        "note": settings.get('note'),
                        "kind": item_kind
                    })

            print(f"✅ Total items found: {len(items)}")
            return items

        except Exception as e:
            print(f"⚠️ Firestore list failed: {e}")

    # Local JSON branch
    print("🔍 Searching local JSON files...")
    for name in os.listdir(DATA_DIR):
        if not name.endswith(".json"):
            continue
        try:
            with open(os.path.join(DATA_DIR, name), "r", encoding="utf-8") as f:
                q = json.load(f)

            qid = q.get("id") or name.replace(".json", "")
            title = q.get("title") or "Untitled"
            meta = q.get("metadata") or {}
            item_kind = meta.get("kind", "quiz")

            if kind and item_kind != kind:
                continue

            items.append({
                "id": qid,
                "title": title,
                "created_at": q.get("created_at"),
                "questions_count": len(q.get("questions", [])),
                "metadata": meta,
                "questions": q.get("questions", []),
                "kind": item_kind
            })

        except Exception as e:
            print(f"⚠️ Error loading local file {name}: {e}")
            continue

    items.sort(key=lambda v: str(v.get("created_at") or ""), reverse=True)
    print(f"✅ Returning {len(items)} items")
    return items


# ----------------------------------------------------
#   SUBMISSIONS
# ----------------------------------------------------
def save_submission(quiz_id: str, student_data: Dict[str, Any]) -> Optional[str]:
    """
    Save a submission. NOW enforces one-attempt at the DB level too.
    Normalizes student_email to lowercase before saving.
    """
    if not _db:
        print("⚠️ Firestore not available, cannot save submission")
        return None
    try:
        # Detect collection
        collection_name = "AIquizzes"
        kind_hint = (student_data or {}).get("kind", "").lower()
        if kind_hint in ("assignment_submission", "assignment"):
            collection_name = "assignments"
        elif kind_hint in ("quiz_submission", "quiz"):
            collection_name = "AIquizzes"
        else:
            try:
                if _db.collection("AIquizzes").document(quiz_id).get().exists:
                    collection_name = "AIquizzes"
                elif _db.collection("assignments").document(quiz_id).get().exists:
                    collection_name = "assignments"
            except Exception:
                pass

        student_email = (student_data.get("email") or student_data.get("student_email") or "").strip().lower()

        payload = {
            "quiz_id": quiz_id,
            "student_email": student_email,
            "student_name": student_data.get("name") or student_data.get("student_name"),
            "roll_no": student_data.get("roll_no", ""),
            "answers": student_data.get("answers", {}),
            "files": student_data.get("files", {}),
            "score": student_data.get("score", 0),
            "total_questions": student_data.get("total_questions", 0),
            "status": student_data.get("status", "completed"),
            "time_taken_sec": student_data.get("time_taken_sec", 0),
            "submitted_at": datetime.utcnow(),
            "kind": student_data.get("kind", "quiz_submission")
        }

        ref = _db.collection(collection_name).document(quiz_id).collection("submissions").add(payload)
        submission_id = ref[1].id
        print(f"✅ Submission saved: {submission_id} (student: {student_email})")
        return submission_id
    except Exception as e:
        print(f"❌ save_submission failed: {e}")
        return None


def get_submission_by_id(submission_id: str) -> Optional[Dict[str, Any]]:
    """
    Retrieve a specific submission document by its ID.
    """
    if not _db:
        return None

    try:
        for collection_name in ['AIquizzes', 'assignments']:
            for qdoc in _db.collection(collection_name).stream():
                qid = qdoc.id
                subref = (
                    _db.collection(collection_name)
                    .document(qid)
                    .collection('submissions')
                    .document(submission_id)
                )
                sub = subref.get()
                if not sub.exists:
                    continue
                s = sub.to_dict() or {}
                return {
                    "submission_id": submission_id,
                    "quiz_id": qid,
                    "collection": collection_name,
                    "student_email": s.get("student_email") or s.get("email"),
                    "student_name": s.get("student_name") or s.get("name"),
                    "roll_no": s.get("roll_no", ""),
                    "answers": s.get("answers", {}),
                    "files": s.get("files", {}),
                    "score": s.get("score", 0),
                    "max_total": s.get("max_total"),
                    "total_questions": s.get("total_questions", 0),
                    "status": s.get("status", "completed"),
                    "submitted_at": s.get("submitted_at"),
                    "kind": s.get("kind", "quiz_submission")
                }

        return None
    except Exception as e:
        print(f"❌ get_submission_by_id failed: {e}")
        return None


def get_submissions_for_quiz(quiz_id: str):
    if not _db:
        print("Firestore not available")
        return []

    try:
        quiz_data = get_quiz_by_id(quiz_id)
        collection_name = "AIquizzes"
        if quiz_data and quiz_data.get("metadata", {}).get("kind") == "assignment":
            collection_name = "assignments"

        submissions_ref = _db.collection(collection_name).document(quiz_id).collection("submissions")
        submissions = []
        for doc in submissions_ref.stream():
            item = doc.to_dict()
            item["id"] = doc.id
            submissions.append(item)

        return submissions

    except Exception as e:
        print("❌ get_submissions_for_quiz failed:", e)
        return []


# Keep old name as alias for grading_routes.py compatibility
def get_submitted_quiz_ids_legacy(submission_id: str) -> Optional[Dict[str, Any]]:
    """Legacy alias — now delegates to get_submission_by_id."""
    return get_submission_by_id(submission_id)


# ----------------------------------------------------
#   DEBUG HELPERS
# ----------------------------------------------------
def debug_list_all():
    print("=" * 50)
    print("📊 DEBUG: ALL ITEMS IN DATABASE:")
    all_items = list_quizzes()
    for item in all_items:
        print(f"  - ID: {item['id']} | Title: {item['title']} | Kind: {item.get('kind', 'not_set')}")
    print(f"📊 TOTAL: {len(all_items)} items")
    print("=" * 50)
    return all_items